<!DOCTYPE html>
<html>

<head>
    <title>首頁</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../css/style_index.css">
    <link rel="stylesheet" type="text/css" href="../css/style_image.css">
    <link rel="stylesheet" href="https://cdn.static.runoob.com/libs/bootstrap/3.3.7/css/bootstrap.min.css"> 

    <script type="text/javascript" src="https://cdn.static.runoob.com/libs/jquery/2.1.1/jquery.min.js"></script> 
    <script type="text/javascript" src="https://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
    <script type="text/javascript" src="../js/test.js"></script>
</head>

<body onload="startclock(); timerONE=window.setTimeout"> 
    <div class="title">
        <div>
            <img src="../img/logo.jpg" height="100px" style="margin-top: -20px; margin-left: calc(50% - 25px);">
        </div>
    </div>

    <ul>
        <li><a class="title_active" href="index.html">Home</a></li>
        <li><a  href="news.html">News</a></li>
        <li><a  href="search.php">Search</a></li>
        <li style="float: right"><a href="Login.html">Login</a></li>
    </ul>

    <script>
        $(".carousel").carousel({
        interval: 4000
        })
    </script>

    <div class="container" style="margin:120px auto; overflow: hidden; width: 68%; height: 1000px; background-color: white; opacity: 0.7; margin-top: 13em;" >
    
        <div id="mark_text">
            
            <div style="padding: 1em;">
                <a style="color: red;text-decoration: none;" href="news.html">最新消息</a>
            </div>
                
                <div style="padding: 0.3em;width: 50%">
                    <img src="../img/news_img.jpg" width="200em" height="200em">
                </div>  
                <div class="in_text">         
                    【主題書展】臺灣原住民族歷史事件<br>
                    展出時間：2019/7/1~12/31<br>
                    展出地點：臺北市...<br><br><br>
                </div>
                <div class="in_text">         
                    2020「VuVu的生活記憶」兒童寒假特別活動<br>
                    展出時間：2020/1/21~2/9<br>
                    展出地點：臺北市...<p class="more"><a href="news.html">more+</a></p><br>
                </div>

            <div style="position: relative; top:-10em;">
                <div style="padding: 1em;">
                    <a style="color: red;text-decoration: none;" href="image.html">本月推薦</a>
                </div>
            
                <div style="padding: 0.3em;width: 50%">
                    <img src="../img/image/p1/01.gif" width="200em" height="200em">
                </div>  
                <div class="in_text">
                    <a href="p3.html"><img style="border-radius:20px;" src="../img/image/p3/01.jpg" width="75em" height="75em"></a>     
                    &nbsp; &nbsp;&nbsp;族群簡介
                </div>
                <div class="in_text">
                    <br><br>
                    <a href="p5.html"><img style="border-radius:20px;" src="../img/image/p5/01.jpg" width="75em" height="75em"></a>     
                    &nbsp; &nbsp;&nbsp;活動照片  
                    <p class="more"><a href="image.html">more+</a></p><br>
                </div>
            </div>

            <div style="position: relative; top:-20em;">
                <div style="padding: 1em;">
                    <a style="color: red;text-decoration: none;" href="search.html">館藏查詢</a>
                </div>
                
                <div style="padding: 0.3em;width: 50%">
                    <img src="../img/image/001.jpg" width="200em" height="200em">
                </div>  
                <div class="in_text" >
                    <a style="color: darkgray; text-decoration: none;" href="video.html">      
                    總類&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    哲學類&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    宗教類<br><br>
                    自然科學&nbsp;&nbsp;&nbsp;
                    應用科學&nbsp;&nbsp;&nbsp;
                    社會科學<br><br>
                    史地類&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    傳記類&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    語文類<br><br>
                    美術類</a><br>
                    <p class="more"><a href="search.html">more+</a></p><br>
                </div>
            </div>

            <div style="padding: 1em;position: relative;top: -82em;left: 33em;">
                <script type="text/javascript" style="position: relative; right: 0;">  
                        calendar(); 
                </script>
            </div>
            
        </div>
            <div style="margin: 300px 1px 1px 700px;" class="desc">
                <h3>相關連結</h3><br>
                <div><a href="http://www.ipcf.org.tw/" target="_blank">
                    <img src="../img/index/05.JPG" style="width: 250px; height: 100px; margin: 10px; padding: 10px; border: 1px gray solid;"/>
                    </a></div>
                <div><a href="http://www.tyipdf.com.tw/" target="_blank">
                    <img src="../img/index/06.JPG" style="width: 250px; height: 100px; margin: 10px; padding: 10px; border: 1px gray solid;"/>
                    </a></div>
                <div><a href="http://www.millet.org.tw/" target="_blank">
                    <img src="../img/index/07.JPG" style="width: 250px; height: 100px; margin: 10px; padding: 10px; border: 1px gray solid;"/>
                    </a></div>
                <div><a href="https://www.laf.org.tw/index.php?action=service_product_detail&Sn=132&sid=4" target="_blank">
                    <img src="../img/index/08.JPG" style="width: 250px; height: 100px; margin: 10px; padding: 10px; border: 1px gray solid;"/>
                    </a></div>
                <div><a href="http://www.tipp.org.tw/website_detail.asp?F_ID=54490&FT_No=10" target="_blank">
                    <img src="../img/index/09.JPG" style="width: 250px; height: 100px; margin: 10px; padding: 10px; border: 1px gray solid;"/>
                    </a></div>
            </div>
    </div>

</body>

</html>